package com.nigmacode.apirest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.nigmacode.apirest.entity.Tipo_evento;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TipoEventoRepository extends JpaRepository<Tipo_evento, Integer>{
    List<Tipo_evento> findByNombre(String nombre);
}
