package com.nigmacode.apirest.service;

import java.util.List;
import java.util.Optional;

import com.nigmacode.apirest.entity.Tipo_evento;
import com.nigmacode.apirest.entity.Tipo_evento;
import com.nigmacode.apirest.repository.TipoEventoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

@Service
public class TipoEventoServiceImpl implements TipoEventoService{

    @Autowired
    private TipoEventoRepository tipoEventoRepository;


    @Override
    public List<Tipo_evento> findAll() {
        List<Tipo_evento> list = tipoEventoRepository.findAll();
        return list;
    }

    @Override
    public Optional<Tipo_evento> findById(int cod_tipo_evento) {
        Optional<Tipo_evento> list = tipoEventoRepository.findById(cod_tipo_evento);
        return list;
    }

    @Override
    public void save(Tipo_evento tipo_evento) {
        tipoEventoRepository.save(tipo_evento);
    }

    @Override
    public void deleteById(int cod_tipo_evento) {
        tipoEventoRepository.deleteById(cod_tipo_evento);
    }

    @Override
    public List<Tipo_evento> findByNombre(String nombre) {
        List<Tipo_evento> list = tipoEventoRepository.findByNombre(nombre);
        return list;
    }

    @Override
    public List<Tipo_evento> findByExample(Tipo_evento tipo_evento) {
        Example<Tipo_evento> tipo_eventoExample = Example.of(tipo_evento);
        List<Tipo_evento> list = tipoEventoRepository.findAll(tipo_eventoExample);
        return list;
    }
}
