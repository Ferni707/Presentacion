package com.nigmacode.apirest.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.nigmacode.apirest.entity.Recordatorio;
import org.springframework.stereotype.Repository;
import java.util.List;

public interface RecordatorioRepository extends JpaRepository<Recordatorio, Integer>{

    List<Recordatorio> findByNombre(String nombre);
}
