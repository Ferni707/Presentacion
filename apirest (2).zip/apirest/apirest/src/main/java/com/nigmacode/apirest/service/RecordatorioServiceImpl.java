package com.nigmacode.apirest.service;

import java.util.List;
import java.util.Optional;

import com.nigmacode.apirest.entity.Recordatorio;
import com.nigmacode.apirest.repository.RecordatorioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

@Service
public class RecordatorioServiceImpl implements RecordatorioService{

    @Autowired
    private RecordatorioRepository recordatorioRepository;

    @Override
    public List<Recordatorio> findAll() {
        List<Recordatorio> list = recordatorioRepository.findAll();
        return list;
    }

    @Override
    public Optional<Recordatorio> findById(int cod_recordatorio) {
        Optional<Recordatorio> list = recordatorioRepository.findById(cod_recordatorio);
        return list;
    }

    @Override
    public void save(Recordatorio recordatorio) {
        recordatorioRepository.save(recordatorio);
    }

    @Override
    public void deleteById(int cod_recordatorio) {
        recordatorioRepository.deleteById(cod_recordatorio);
    }

    @Override
    public List<Recordatorio> findByNombre(String nombre) {
        List<Recordatorio> list = recordatorioRepository.findByNombre(nombre);
        return list;
    }

    @Override
    public List<Recordatorio> findByExample(Recordatorio recordatorio) {
        Example<Recordatorio> recordatorioExample = Example.of(recordatorio);
        List<Recordatorio> recordatorios = recordatorioRepository.findAll(recordatorioExample);

        return recordatorios;
    }
}
