package com.nigmacode.apirest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.nigmacode.apirest.entity.Recordatorio;
import com.nigmacode.apirest.entity.Usuario;
import com.nigmacode.apirest.service.RecordatorioService;
import com.nigmacode.apirest.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")

public class RecordatorioRestController {

    @Autowired
    private RecordatorioService recordatorioService;

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/recordatorio")
    public List<Recordatorio> findAll() {
        try {

        } catch (IllegalArgumentException err){
            List<Recordatorio> p = new ArrayList<>();
            return p;
        }
        return recordatorioService.findAll();
    }

    @GetMapping("/recordatorio/ID/{recordatorioId}")
    public Optional<Recordatorio> getAyuda(@PathVariable int recordatorioId){
        Optional<Recordatorio> recordatorio = recordatorioService.findById(recordatorioId);

        if(recordatorio == null) {
            throw new RuntimeException("Recordatorio id not found -"+recordatorioId);
        }
        else {
            return recordatorio;
        }
    }

    @GetMapping("/recordatorio/{nombre}")
    public List<Recordatorio> getNombre(@PathVariable String nombre){
        List<Recordatorio> recordatorioList = recordatorioService.findByNombre(nombre);

        if(recordatorioList == null) {
            throw new RuntimeException("Recordatorio theme not found -"+nombre);
        }

        return recordatorioList;
    }

    @GetMapping("/recordatorio/params")
    public List<Recordatorio> findByParameters(@RequestBody Recordatorio recordatorio){

        recordatorio.setUsuario(1);
        List<Recordatorio> list = recordatorioService.findByExample(recordatorio);
        for (Recordatorio u :list) {
            u.toString();
        }
        if(list.isEmpty()){
            throw new RuntimeException("Recordatorio not found");
        }
        return list;
    }

    @PostMapping("/recordatorio")
    public Recordatorio addRecordatorio(@RequestBody Recordatorio recordatorio) {

        recordatorio.setCod_recordatorio(0);

        Optional<Usuario> us = usuarioService.findById(recordatorio.getUsuario());
        if(us == null){
            throw new RuntimeException("El usuario "+recordatorio.getUsuario()+" no existe");
        } else {
            recordatorioService.save(recordatorio);
        }
        return recordatorio;

    }

    @PutMapping("/recordatorio")
    public Recordatorio updateRecordatorio(@RequestBody Recordatorio recordatorio) {
        recordatorioService.save(recordatorio);
        return recordatorio;
    }

    @DeleteMapping("/recordatorio/{recordatorioId}")
    public String deleteRecordatorio(@PathVariable int recordatorioId) {

        Optional<Recordatorio> recordatorio = recordatorioService.findById(recordatorioId);

        if(recordatorio == null) {
            throw new RuntimeException("Recordatorio id not found -"+recordatorioId);
        }
        recordatorioService.deleteById(recordatorioId);

        return "Deleted recordatorio id - "+recordatorioId;
    }
}
