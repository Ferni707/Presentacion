package com.nigmacode.apirest.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="Tipo_evento")
public class Tipo_evento {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="cod_tipo_evento")
    private Integer cod_tipo_evento;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "color")
    private String color;

    @Column(name = "formal")
    private boolean formal;

    @Column(name = "evento")
    private int evento;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "evento", referencedColumnName = "cod_evento", insertable = false, updatable = false)
    @JsonIgnoreProperties("tipo_eventos")
    private Evento eventos;

    public Tipo_evento() {
    }

    public Tipo_evento(Integer cod_tipo_evento, String nombre, String color, boolean formal, int evento) {
        this.cod_tipo_evento = cod_tipo_evento;
        this.nombre = nombre;
        this.color = color;
        this.formal = formal;
        this.evento = evento;
    }

    public Integer getCod_tipo_evento() {
        return cod_tipo_evento;
    }

    public void setCod_tipo_evento(Integer cod_tipo_evento) {
        this.cod_tipo_evento = cod_tipo_evento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isFormal() {
        return formal;
    }

    public void setFormal(boolean formal) {
        this.formal = formal;
    }

    public int getEvento() {
        return evento;
    }

    public void setEvento(int evento) {
        this.evento = evento;
    }

    @Override
    public String toString() {
        return "Tipo_evento{" +
                "cod_tipo_evento=" + cod_tipo_evento +
                ", nombre='" + nombre + '\'' +
                ", color='" + color + '\'' +
                ", formal=" + formal +
                ", evento=" + evento +
                '}';
    }
}
