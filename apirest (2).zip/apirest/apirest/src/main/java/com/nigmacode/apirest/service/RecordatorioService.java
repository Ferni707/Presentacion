package com.nigmacode.apirest.service;

import java.util.List;
import java.util.Optional;
import com.nigmacode.apirest.entity.Recordatorio;

public interface RecordatorioService {

    public List<Recordatorio> findAll();

    public Optional<Recordatorio> findById(int cod_recordatorio);

    public void save(Recordatorio recordatorio);

    public void deleteById(int cod_recordatorio);

    public List<Recordatorio> findByNombre(String nombre);

    public List<Recordatorio> findByExample(Recordatorio recordatorio);
}
