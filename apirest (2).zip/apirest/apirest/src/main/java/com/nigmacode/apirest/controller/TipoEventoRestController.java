package com.nigmacode.apirest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.nigmacode.apirest.entity.Tipo_evento;
import com.nigmacode.apirest.entity.Evento;
import com.nigmacode.apirest.entity.Usuario;
import com.nigmacode.apirest.repository.TipoEventoRepository;
import com.nigmacode.apirest.service.TipoEventoService;
import com.nigmacode.apirest.service.EventoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class TipoEventoRestController {

    @Autowired private TipoEventoService tipoEventoService;
    @Autowired private EventoService eventoService;

    @GetMapping("/tipo_evento")
    public List<Tipo_evento> findAll() {
        try {

        } catch (IllegalArgumentException err){
            List<Tipo_evento> p = new ArrayList<>();
            return p;
        }
        return tipoEventoService.findAll();
    }

    @GetMapping("/tipo_evento/ID/{tipo_eventoId}")
    public Optional<Tipo_evento> getTipo_evento(@PathVariable int tipo_eventoId){
        Optional<Tipo_evento> tipo_evento = tipoEventoService.findById(tipo_eventoId);

        if(tipo_evento == null) {
            throw new RuntimeException("Tipo_evento id not found -"+tipo_eventoId);
        }
        else {
            return tipo_evento;
        }
    }

    @GetMapping("/tipo_evento/{tema}")
    public List<Tipo_evento> getNombre(@PathVariable String nombre){
        List<Tipo_evento> tipo_eventoList = tipoEventoService.findByNombre(nombre);

        if(tipo_eventoList == null) {
            throw new RuntimeException("Tipo_evento theme not found -"+nombre);
        }

        return tipo_eventoList;
    }

    @GetMapping("/tipo_evento/params")
    public List<Tipo_evento> findByParameters(@RequestBody Tipo_evento tipo_evento){

        tipo_evento.setEvento(1);
        List<Tipo_evento> list = tipoEventoService.findByExample(tipo_evento);
        for (Tipo_evento u :list) {
            u.toString();
        }
        if(list.isEmpty()){
            throw new RuntimeException("Tipo_evento not found");
        }
        return list;
    }

    @PostMapping("/tipo_evento")
    public Tipo_evento addTipoEvento(@RequestBody Tipo_evento tipo_evento) {

        tipo_evento.setCod_tipo_evento(0);

        Optional<Evento> ev = eventoService.findById(tipo_evento.getEvento());
        if(ev == null){
            throw new RuntimeException("El evento "+tipo_evento.getEvento()+" no existe");
        } else {
            tipoEventoService.save(tipo_evento);
        }
        return tipo_evento;

    }

    @PutMapping("/tipo_evento")
    public Tipo_evento updateTipoEvento(@RequestBody Tipo_evento tipo_evento) {
        tipoEventoService.save(tipo_evento);
        return tipo_evento;
    }

    @DeleteMapping("/tipo_evento/{tipo_eventoId}")
    public String deleteTipoEvento(@PathVariable int tipo_eventoId) {

        Optional<Tipo_evento> tipo_evento = tipoEventoService.findById(tipo_eventoId);

        if(tipo_evento == null) {
            throw new RuntimeException("Tipo_evento id not found -"+tipo_eventoId);
        }
        tipoEventoService.deleteById(tipo_eventoId);

        return "Deleted tipo_evento id - "+tipo_eventoId;
    }
}
