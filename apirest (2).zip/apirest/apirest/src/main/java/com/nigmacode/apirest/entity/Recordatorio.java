package com.nigmacode.apirest.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Recordatorio")
public class Recordatorio {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "cod_recordatorio")
    private Integer cod_recordatorio;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "informacion")
    private String informacion;

    @Column(name = "usuario")
    private int usuario;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario", referencedColumnName = "cod_usuario", insertable = false, updatable = false)
    @JsonIgnoreProperties("recordatorios")
    private Usuario usuario1;

    public Recordatorio() {
    }

    public Recordatorio(Integer cod_recordatorio, String nombre, String informacion, int usuario) {
        this.cod_recordatorio = cod_recordatorio;
        this.nombre = nombre;
        this.informacion = informacion;
        this.usuario = usuario;
    }

    public Integer getCod_recordatorio() {
        return cod_recordatorio;
    }

    public void setCod_recordatorio(Integer cod_recordatorio) {
        this.cod_recordatorio = cod_recordatorio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getInformacion() {
        return informacion;
    }

    public void setInformacion(String informacion) {
        this.informacion = informacion;
    }

    public int getUsuario() {
        return usuario;
    }

    public void setUsuario(int usuario) {
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return "Recordatorio{" +
                "cod_recordatorio=" + cod_recordatorio +
                ", nombre='" + nombre + '\'' +
                ", informacion='" + informacion + '\'' +
                ", usuario=" + usuario +
                '}';
    }
}
