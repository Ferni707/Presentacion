package com.nigmacode.apirest.service;

import com.nigmacode.apirest.entity.Tipo_evento;
import java.util.List;
import java.util.Optional;

public interface TipoEventoService {

    public List<Tipo_evento> findAll();

    public Optional<Tipo_evento> findById(int cod_tipo_evento);

    public void save(Tipo_evento tipo_evento);

    public void deleteById(int cod_tipo_evento);

    public List<Tipo_evento> findByNombre(String nombre);

    public List<Tipo_evento> findByExample(Tipo_evento tipo_evento);
}
